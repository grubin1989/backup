#!/bin/bash 
#set -x 
#***********************************************************
#history: 
#   2014-08-21 : /wesoft folder check,solaris
#	  2014-08-22 : modify sudo -c (not all have /root/), ssh_check (match $ and ~), solaris version judge
#		             hpux pwgrd, hpux telnet exit
#		       aix
#	  2014-08-25 : cimserver service check, modify nscd ( -z $tmp_file)
#	  2014-08-28 : change ftp message, ftp match info
#   2014-09-02 : check the hostname(.site) on SUSE, check telnet login and sudo together
#   2014-09-14 : enhance the ssh_login to use the rsa key to authenticate. 
#                Create 2 running way, the default is interactive check, the second is non-interactive check 
#   2014-11-26 : Enhance the freespace check for /var, /usr and /tmp, if no one of them, check root dir "/"
#								 Update the permission for /wesoft and subfolder to 777, Update the script about check rpcbind or portmap
#***********************************************************
#already test on these machines,
#Solaris 10 U9 x86 with sparse zone and whole zone (10.100.52.106)
#SLES 11 SP3 (10.100.52.48)
#HPUX 11.23 PA (10.100.52.104)
#Solaris 9 x86 (MinPatch) (10.100.62.155)
#Ubuntu Server 10.04.4 LTS (10.100.51.195)
#
#***********************************************************

#--------------------Variable Setting-----------------------
tmp_file=/tmp/tmp_file_verify
trap 'rm -f /tmp/tmp_file_verify' EXIT

#----------Print Ok/FAIL/WARNING/delimiter------------------
print_ok(){
	printf "%-58s\033[32m [  OK  ]\033[0m \n\r" "$1" 
}
print_fail(){
	printf "%-58s\033[31m [FAILED]\033[0m \n\r" "$1" 
}
print_warning(){
	printf "%-58s\033[33m [WARNING]\033[0m \n\r" "$1" 
}
print_delimiter() {
echo "-----------------------------------------"
}

#--------------------------Logo-----------------------------
logo(){

print_delimiter
logo_info="WELCOME to the mache Verification Wizard"
echo -e "\033[32m $logo_info \033[0m"

}

#--------------recreate super/normal if not exist------------
super_normal_exist() {
	print_delimiter
	flag=0
	echo -e "'super/normal account exist' check\r"
	if [ 1 -eq  "`grep -c super /etc/passwd`" ]; then
		echo "'super'        exist!" 
		let flag+=1
	else 
		echo "'super'    not exist!"
	fi
	if [ 1 -eq  "`grep -c normal /etc/passwd`" ]; then
		echo "'normal'       exist!" 
		let flag+=1
	else
		echo "'normal'   not exist!"
	fi

	if [ $flag -eq 2 ];then
       		 print_ok "'super' and 'normal' account check"
	else

		MSG_FAIL="'super' and 'normal' accounts check"
		print_fail "$MSG_FAIL"
		ssh_login_flag=0
	fi
}
#-------------Super/normal exist first------------------
id_check() {
	print_delimiter
	echo -e "'id super/normal' check "
	flag=0
	for local_user in super normal
	  do
       		set $(id $local_user) &>/dev/null
                uid=$1
                gid=$2
        	if [ "uid=501(super)" = "$uid" ] && [ "gid=501(super)" = "$gid" ]; then
			let flag+=1
                elif [ "uid=502(normal)" = "$uid" ] && [ "gid=502(normal)" = "$gid" ]; then
			let flag+=1
                fi 
	  done
		[ $flag -eq 2 ]&& print_ok "'id super' or 'id normal' check"&&return
		print_fail "'id super' and id normal check"
                
}

#------------ssh_check, based on telnet login and user's homedir-----------
ssh_check() {
print_delimiter
        echo -e "'ssh login' check\n"
       # echo -e "\e[0;31m Press Ctrl + D after input the password!\r\e[0m"
	#echo -e "\e[0;33mIF no response, pls exit and check ssh login  manually!\e[0m"
	#echo -e "\e[0;31mIF no response, pls exit and check ssh login  manually!\e[0m"
	rm -rf /tmp/tmp_file  >/dev/null 2>&1
	rm -rf /tmp/tmp_file1  >/dev/null 2>&1

#ssh commands are located under /usr/local/bin/ on Solaris 8
sshkeygencmd=$(ls /usr/bin/ssh-keygen 2>/dev/null || echo /usr/local/bin/ssh-keygen )
sshkeyscancmd=$(ls /usr/bin/ssh-keyscan 2>/dev/null || echo /usr/local/bin/ssh-keyscan)
	
	for local_user in super normal root
                do
                {
                                sleep 4
                         echo "$local_user"
                                sleep 4
                         echo "password"
                                sleep 4
                                echo " $sshkeygencmd -t rsa"
                                sleep 2
                                echo ""
                                sleep 2
                                echo ""
                                sleep 2
                                echo ""
                                sleep 2
                  echo "cat .ssh/id_rsa.pub  >> .ssh/authorized_keys"
                                sleep 2
                                echo " $sshkeyscancmd -t rsa localhost > .ssh/known_hosts"
                                sleep 2
                         echo "cd /wesoft"
                         sleep 2
                                echo "ssh $local_user@localhost pwd > /tmp/tmp_file1"
                                sleep 2
                                echo "ssh $local_user@localhost pwd "
                                echo "exit"
                                sleep 2
                } | telnet localhost &> /tmp/tmp_file

                if grep "$homedir"super /tmp/tmp_file  >/dev/null 2>&1
                then
                	print_ok  " $local_user user ssh login successfully"
                 elif grep "$homedir"super /tmp/tmp_file1  >/dev/null 2>&1
                then
                	print_ok  " $local_user user ssh login successfully"
                elif grep "$homedir"normal /tmp/tmp_file  >/dev/null 2>&1 
                then
               	 	print_ok  " $local_user user ssh login successfully"
               	elif grep "$homedir"normal /tmp/tmp_file1  >/dev/null 2>&1 
                then
               	 	print_ok  " $local_user user ssh login successfully"
		elif grep "$roothomedir" /tmp/tmp_file  >/dev/null 2>&1 
                then
               	 	print_ok  " $local_user user ssh login successfully"
               	elif grep "$roothomedir" /tmp/tmp_file1  >/dev/null 2>&1 
                then
               	 	print_ok  " $local_user user ssh login successfully"
                	else
                	MSG_FAIL="'$local_user' ssh: Login failed!!"
                	print_fail "$MSG_FAIL"
                	echo -e "\033[33m ---Note:This may caused by timeout, pls check manually! \033[0m"
                	fi
                	
                	rm -rf /tmp/tmp_file  >/dev/null 2>&1
                	rm -rf /tmp/tmp_file1  >/dev/null 2>&1
                	rm -rf $homedir$local_user/.ssh  >/dev/null 2>&1
			rm -rf $roothomedir/.ssh  >/dev/null 2>&1
        done
}
#----------rsh check -----------
rsh_rlogin_check(){
# rsh / rlogin with -l will require input password
print_delimiter
        echo -e "'rsh & rlogin login' check\n"
       # echo -e "\e[0;31m Press Ctrl + D after input the password!\r\e[0m"
	rm -rf /tmp/tmp_file  >/dev/null 2>&1
	rm -rf /tmp/tmp_file1  >/dev/null 2>&1
	rm -rf /tmp/tmp_file2  >/dev/null 2>&1
	if ls /etc/hosts.equiv >/dev/null 2>&1
	then
		 cp -p /etc/hosts.equiv /etc/hosts.equiv_bak
	 fi
	 
	 if ls ~/.rhosts >/dev/null 2>&1
	 then
		 cp -p ~/.rhosts ~/.rhosts_bak
	 fi
	 
	 echo "localhost" >/etc/hosts.equiv
	 echo "localhost super" > ~/.rhosts
	 echo "localhost  norml" > ~/.rhosts
	 
  for local_user in super normal
  do
    {
                                sleep 2
                         echo "$local_user"
                                sleep 2
                         echo "password"
                                sleep 4
                         echo "cd /wesoft"
                         sleep 2
                                echo "rsh localhost pwd > /tmp/tmp_file1"
                                sleep 2
                                echo "rlogin localhost "
                                sleep 4
                                echo "id > /tmp/tmp_file2"
                                sleep 2
                                if [[ `pwd` != "/wesoft" ]]
                                then 
                                	echo "exit"
                                fi
                                sleep 2
                                echo "exit"
                                sleep 2
                } | telnet localhost &> /tmp/tmp_file

                if grep "$homedir"$local_user /tmp/tmp_file  >/dev/null 2>&1
                then
                	print_ok  " $local_user user rsh login successfully"
                 elif grep "$homedir"$local_user /tmp/tmp_file1  >/dev/null 2>&1
                then
                	print_ok  " $local_user user rsh login successfully"
                else
                	MSG_FAIL="'$local_user' rsh : Login failed!!"
                	print_fail "$MSG_FAIL"
                	echo -e "\033[33m ---Note:'rsh login fail' may caused by timeout, pls check manually! \033[0m"
                fi
                
                if grep "uid=" /tmp/tmp_file  >/dev/null 2>&1 
                then
               	 	print_ok  " $local_user user rlogin successfully"
               	elif grep "uid=" /tmp/tmp_file2  >/dev/null 2>&1 
                then
               	 	print_ok  " $local_user user rlogin successfully"
                	else
                	MSG_FAIL="'$local_user' rlogin: Login failed!!"
                	print_fail "$MSG_FAIL"
                	echo -e "\033[33m ---Note:'rlogin fail' may caused by timeout, pls check manually! \033[0m"
                	fi                	
                	rm -rf /tmp/tmp_file  >/dev/null 2>&1
                	rm -rf /tmp/tmp_file1  >/dev/null 2>&1
                	rm -rf /tmp/tmp_file2  >/dev/null 2>&1
        done
        
if ls /etc/hosts.equiv_bak >/dev/null 2>&1
then 
		cp -p /etc/hosts.equiv_bak /etc/hosts.equiv
		rm -rf /etc/hosts.equiv_bak
fi

if ls ~/.rhosts_bak >/dev/null 2>&1
then
   cp -p ~/.rhosts_bak ~/.rhosts
   rm -rf ~/.rhosts_bak
fi

}
#----------Telnet sleep time may need to modify---------
telnet_sudo_check() {
print_delimiter
        echo -e "'Telnet login and sudo' check\n"
        sudo &> "$tmp_file"
			if [ -z "`grep \[Uu\]sage $tmp_file`" ];then
			print_fail "'sudo' package not install!"
			fi
		rm /tmp/tmp_file >/dev/null 2>&1
	for local_user in super normal root
		do
		{
				sleep 4
			 echo "$local_user"
				sleep 4
			 echo "password"
				sleep 4
			if [[ $local_user == "super" ]]
			then
					echo "sudo id;pwd "
					sleep 2
				else
			 		echo "id "
			 	fi
				sleep 2
				#echo "" 
				#sleep 2
				#echo "" 
				#sleep 2
				#echo ""
				#sleep 2 
				#echo "" 
			 echo "exit" 	
			 sleep 4
		} | telnet localhost &> "$tmp_file"
		
		
		
		if [ -n "`grep '/super' $tmp_file`" ]; then

			MSG_OK="'$local_user'  telnet: Login successfully!"
			print_ok "$MSG_OK"
			if [ -n "`grep 'uid=0' $tmp_file`" ]; then
			print_ok "'sudo' super check successfully" 
			#elif [ -n "`grep 'uid=0' /tmp/tmp_file`" ]; then
			#print_ok "'sudo' super check successfully" 
			else
			print_fail "maybe super sudo works abnormally! pls check it manually!"
			fi		
		elif [ -n "`grep '502' $tmp_file`" ]; then
			MSG_OK="'$local_user' telnet: Login successfully!"
			print_ok "$MSG_OK"
		elif [ -n "`grep 'uid=0' $tmp_file`" ]; then
			MSG_OK="'$local_user' telnet: Login successfully!"
			print_ok "$MSG_OK"
		else
			MSG_FAIL="'$local_user' telnet: Login failed!!"
			print_fail "$MSG_FAIL"		  
			echo -e "\033[33m ---Note:This may caused by timeout, pls check manually! \033[0m"
			if [[ $local_user != "root" ]]
			then
				ssh_login_flag=0
			fi
		fi
	done
	rm /tmp/tmp_file >/dev/null 2>&1
}

#-----------------------The Menu-----------------------
platform_menu_choice() {
print_delimiter
echo "Option:-"
echo                                                             
echo  " a|A) AIX                                                 "
echo  " h|H) HPUX                                                "
echo  " l|L) Linux       		                                     "
echo  " s|S) Solaris                                             "
echo  " m|M) Mac                                             "
echo  " q|Q) Quit				                                         "
echo
echo -e "Please enter choice then press return [ a|h|l|s|m|q ]:\c"
read platform_choice
return
}

#------Home directory must exist first, or failed------
ftp_check() {
print_delimiter
	echo -e "'FTP' check\n"
for local_user in root super normal
do
        ftp -n <<!
        open localhost
        user $local_user password
        prompt
        mkdir /tmp/dir_$local_user
        close
        bye
# Be careful of the following exclamation mark (!) , '!' must be at the beginning of the line
!
        if [ -d "/tmp/dir_$local_user" ]; then
                print_ok "'$local_user' ftp 'login' successfully!"
                rmdir "/tmp/dir_$local_user"
        else
                print_fail "'$local_user' ftp 'login'  fail!"
        fi

done
}

#------------------changelog check----------------------
changelog_check(){
print_delimiter
echo -e "'change_log ' check\n"
if ls /wesoft/changelog.txt >/dev/null 2>&1
then
	print_ok "changelog.txt exists under /wesoft"
else
	print_fail "changelog.txt does not exist under /wesoft or it does not exist!!"
fi
}	

#------------------Home dir check----------------------
home_dir_check(){
  for local_user in super normal
    do
    print_delimiter
    echo -e "'$local_user home dir' check\r"
	flag=0
	ls -ld /home/$local_user &> "$tmp_file"

	#the home directory for solaris is /export/home/username
	[[ $1 = s ]]&& ls -ld /export/home/$local_user &> "$tmp_file"

	if [ -n "`grep 'No such file or directory' $tmp_file`" ]; then
		print_fail "'$local_user' home_dir_check (not exist)"
		flag=2
	else	
		if cat $tmp_file |egrep "drwxr-xr-x|drwx------" >/dev/null 2>&1
		 then
			echo " Mode is 755 or 700"
		else 
			print_warning " Mode is not 755 or 700, is this right?"
		fi
						
		if cat $tmp_file |grep "$local_user *$local_user" >/dev/null 2>&1
		then
			echo " owner and group is $local_user:$local_user"
		else 
			echo " owner and group is not $local_user:$local_user"
			flag=1
		fi
			
	fi
							
	if [ $flag -eq 1 ]; then						
                print_fail "'$local_user' home_dir_check"
                ssh_login_flag=0
        elif [ $flag -eq 0 ]; then                             
                print_ok "'$local_user' home_dir_check"
	fi
  done
}

#-------------------getent check------------------------
getent_check(){ 
 print_delimiter
echo -e "'getent ' check\n"
	getent passwd | egrep 'super|normal'> "$tmp_file"
        if [ `cat $tmp_file|wc -l` -eq 2 ]; then
                print_ok "'getent' check"
        else
                print_fail "'getent' check"
        fi
}

#-----------------IP_Hosts check------------------
IP_Hosts_check(){
print_delimiter
echo -e "'IP_Hosts ' check\n"
	case $1 in

	l) ifconfig -a| egrep "inet.*ask.*ast|inet.*ast.*ask" > "$tmp_file"
	     if [ -z "`grep 'inet addr:' $tmp_file`" ]; then
		ip=$(sed 's/^.*inet //g' $tmp_file | cut -d ' ' -f 1)
             else
		ip=$(sed 's/^.*inet addr://g' $tmp_file | cut -d ' ' -f 1)
             fi
	     ;;
	 a|s) ifconfig -a|grep "inet.*ask.*ffffff00.*cast" > "$tmp_file"
	     ip=$(sed 's/^.*inet //g' $tmp_file | cut -d ' ' -f 1)	
	     ;;
	  h) ifconfig lan0|grep "inet.*ask.*cast" > "$tmp_file"
             ip=$(sed 's/^.*inet //g' $tmp_file | cut -d ' ' -f 1)
             ;;
	 esac	
			
        # check if ip match hostname. if there is no mutilple NICs, no need to check all IPs, such as sparse zone
        for subip in $ip
        do
       #netstat -in will not get the ip for linux os
       if [ $1 = l ]; then 
       		 check="^\s*$subip.*`hostname`\s*"
       		if [ -z "`grep $check /etc/hosts`" ] ; then
                print_fail " $subip <====> $hostname does not match!"
        	else
								MSG_OK="'$subip <====> $hostname' in /etc/hosts check"
                MSG_WARNGING=" $subip <====> $hostname matched but 'ping `hostname` failed!"
                if [ $1 = h ];then
									ping `hostname` -n 3 &>/dev/null && print_ok "$MSG_OK" || print_warning "$MSG_WARNGING"
								else
									ping -c 3 `hostname` &>/dev/null && print_ok "$MSG_OK" || print_warning "$MSG_WARNGING"
								fi
					fi                   		
       else
        	if netstat -in |grep $subip >/dev/null 2>&1
       		then
      	  	check="^\s*$subip.*`hostname`\s*"
        		if [ -z "`grep $check /etc/hosts`" ] ; then
                print_fail " $subip <====> $hostname does not match!"
        		else
								MSG_OK="'$subip <====> $hostname' in /etc/hosts check"
                MSG_WARNGING=" $subip <====> $hostname matched but 'ping `hostname` failed!"
                if [ $1 = h ];then
									ping `hostname` -n 3 &>/dev/null && print_ok "$MSG_OK" || print_warning "$MSG_WARNGING"
								else
									ping -c 3 `hostname` &>/dev/null && print_ok "$MSG_OK" || print_warning "$MSG_WARNGING"
								fi
						fi
       	 fi
       fi
     done
}

#-----------------------alock check----------------------
alock_check() {
print_delimiter
echo -e "'alock  ' check\n"
        /usr/bin/alock > "$tmp_file" 2> /dev/null
        NotUse="No one has reserved this machine"
	Using="This machine has an advisory lock created"
        if [ -n "`grep "$NotUse" "$tmp_file"`" ]; then
                print_warning "'alock' installed, but not reserved!"
        elif [ -n "`grep "$Using" "$tmp_file"`" ]; then
                print_ok "'alock' installed and reserved already!"
        else
                print_fail "'alock' is not installed, istall first!"
        fi
}

#------------------ "hosts:  files dns" check------------
#make sure 'hosts: files' are followed by 'dns', except AIX, AIX does not have this file
nsswitch_check(){
print_delimiter
echo -e "'nsswitch file' check\n"
        if [ -z "`grep '^hosts:.*files.*dns.*' /etc/nsswitch.conf`" ]; then
                print_fail "'/etc/nsswitch.conf'(hosts: file dns) not set correctly!"
        else
                print_ok "'/etc/nsswitch.conf'(hosts: file dns) check"
        fi
}

#----------------set /wesoft/ directory mode ------------
#make sure the folders exist and permission are 755

wesoft_dir_mode(){
print_delimiter
echo -e "'wesoft_dir and subdir ' check\n"
	find /wesoft/ -type d -perm 777 &> "$tmp_file"
	[ -n "`grep "No such file or directory" $tmp_file`" ]&& print_fail "/wesoft/ folder not exist!"&&return;
	flag=0

	if [ -z "`grep "^/wesoft/$" $tmp_file`" ]; then
                echo "'/wesoft/' permission not 777!!"
                flag=1
	fi

	if [ -z "`grep "/wesoft/packages" $tmp_file`" ]; then
                echo "'/wesoft/packages' 	    not exist or permission not 777!!"
                flag=1
        fi

	if [ -z "`grep "^/wesoft/release$" $tmp_file`" ]; then
                echo "'/wesoft/release' 	    not exist or permission not 777!!"
                flag=1
	fi 

        if [ -z "`grep "/wesoft/release/rc" $tmp_file`" ]; then
                echo "'/wesoft/release/rc'        not exist or permission not 777!!"
                flag=1
        fi

        if [ -z "`grep "/wesoft/release/scripts" $tmp_file`" ]; then
                echo "'/wesoft/release/scripts'   not exist or permission not 777!!"
                flag=1
        fi

        if [ -z "`grep "/wesoft/release/manifests" $tmp_file`" ]; then
                echo "'/wesoft/release/manifests' not exist or permission not 777!!"
                flag=1
        fi

        if [ $flag -eq 0 ]; then
		print_ok " /wesoft/* subfolders|permissions check"
	else 
		print_fail " /wesoft/* subfolders|permissions check"
        fi

}

#--------------------------nscd check----------------------
#make sure 'nscd' install and starts when reboot

nscd_check(){
#the package name do not include nscd on someplatform, such as solaris(50.23)
        #case $1 in
		#r) rpm -qa |grep nscd &> "$tmp_file";;
		#d) dpkg -l |grep nscd &> "$tmp_file";;
		#s) pkginfo -l |grep nscd &> "$tmp_file";; 
	#esac
		#sleep 1
	#if [ -z "$(cat $tmp_file)" ]; then
		#print_fail "'nscd' not install!"
		#return
	#fi
	print_delimiter
echo -e "'nscd daemon ' check\n"
		nscdMark="/usr/sbin/nscd"
		 >> "$tmp_file"
	if ps -ef |grep -v grep |grep nscd >/dev/null 2>&1
	 then       
		print_ok "'nscd' daemon start already"
        else  
		print_warning "'nscd' daemon not start, pls check it"
        fi

}

#----------------------UsePAM yes / GSSAPIAuthentication yes check-----------------------
#make sure 'UsePAM yes'
#make sure 'GSSAPIAuthentication yes'

SshdSetting_check(){
print_delimiter
echo -e "'sshd_config ' check\n"

#for Hpux :/opt/ssh/etc/sshd_config, soalris 8: /usr/local/etc/sshd_config, others:/etc/ssh/sshd_config
SSHD_PATH=$(ls /etc/ssh/sshd_config 2>/dev/null || ls /opt/ssh/etc/sshd_config 2>/dev/null || echo /usr/local/etc/sshd_config)
for sshdSetting in UsePAM GSSAPIAuthentication
do
        if [ -z "`grep  "^ *$sshdSetting" $SSHD_PATH`" ]; then
                print_warning "There is not setting $sshdSetting in $SSHD_PATH , pls check manually!"
        elif [ "`grep -c "^ *$sshdSetting" $SSHD_PATH`" -gt 1 ]; then
                print_fail "'$sshdSetting' not unique"
        elif [ -n "`grep "^ *$sshdSetting *yes" $SSHD_PATH`" ]; then
                print_ok "'$sshdSetting yes' check"
	else 
		print_fail "'$sshdSetting yes' check"
	fi
done
}

#---------------------check corefiles.sh-------------------
#check if "checkcorefiles" exists in /usr/bin

checkcorefiles(){
print_delimiter
echo -e "'core files ' check\n"
				ls /usr/bin |grep checkcorefiles > "$tmp_file"
        if ls /usr/bin |grep checkcorefiles >/dev/null 2>&1
        then
					print_ok "'checkcorefiles' exists check"			
					for corefile_script in `cat $tmp_file`
					do
						/usr/bin/$corefile_script > /tmp/tmp_file_check
       			 if [ -n "`grep "Permission denied"  /tmp/tmp_file_check`" ]; then
                print_warning "'$corefile_script' persmission denied!"
             fi
          done
          rm -rf /tmp/tmp_file_check  
       	else
							print_fail "'checkcorefiles' not found in /usr/bin"
                
        fi
        
}

#-----------------------check_log--------------------------
check_log(){
print_delimiter
echo -e "'check_log script ' check\n"
         /usr/bin/check_log &> "$tmp_file"

        if ls /usr/bin/check_log >/dev/null 2>&1
        then
                print_ok "'check_log' check exists!!"
         else
                print_fail "'check_log' not found in /usr/bin"

        fi
        
        if [ -n "`grep "Permission denied"  $tmp_file`" ]; then
                print_warning "'check_log' premission denied!"
        fi
}


#---------------------space /var and /tmp check-------------
space_check(){
print_delimiter
echo -e "'Space for /var & /tmp & /usr ' check\n"
root_dir=0
platform_flag=0

for dir_check in /tmp /var /usr
do
if [[ $platform_choice == "l" || $platform_choice == "a" || $platform_choice == "m" ]]
then
  if df -m  |grep ^"$dir_check"$ >/dev/null 2>&1
  then
  		if [[ $platform_choice == "a" ]]
  		then
				freespace=`df -m  |awk '/ "$dir_check"$/{print $3}' `
			else
				freespace=`df -m  |awk '/ "$dir_check"$/{print $4}' `
			fi
			if [ $freespace -gt "200" ]
			then
			 print_ok "Free Space check for $dir_check"
			else
				print_warning "The free space for $dir_check maybe small, pls note"
			fi
	else
			root_dir=1
			platform_flag=1
	fi
	
#solaris & hp
else
	if df -k  |grep ^"$dir_check"$ >/dev/null 2>&1
  then
  		if [[ $platform_choice == "h" ]]
			then
  			freespace=`df -b |grep "^$dir_check " |awk '{print $5}' `
  		else	
  			freespace=`df -k  |awk '/ "$dir_check"$/{print $4}' `
  		fi  		
  		if [ $freespace -gt "204800" ]
			then
				 print_ok "Free Space check for $dir_check"
			else
					print_warning "The free space for $dir_check maybe small, pls note"
			fi
	else
			root_dir=1
			platform_flag=2
	fi
		
fi

done

if [[ $root_dir == 1 && $platform_flag == 1 ]]
then
		if [[ $platform_choice == "a" ]]
  		then
				freespace=`df -m  |awk '/ \/$/{print $3}' `
			else
				freespace=`df -m  |awk '/ \/$/{print $4}' `
			fi
		if [ $freespace >= "500" ]
		then
			 print_ok "Free Space check for root dir /"
		else
				print_warning "The free space for $dir_check maybe small, pls note"
		fi
else		
  			if [[ $platform_choice == "h" ]]
			then
  			freespace=`df -b |grep "^\/ " |awk '{print $5}' `
  		else	
  			freespace=`df -k  |awk '/ \/$/{print $4}' `
  		fi  		
  			if [ $freespace -gt "512000" ]
				then
					 print_ok "Free Space check for root dir /"
				else
						print_warning "The free space for root dir / maybe small, pls note"
				fi
fi
			
}
#--portmap and rpcbind check, only for debin and ubuntu----
portmap_rpcbind(){		
			uname -a > "$tmp_file"
			if cat $tmp_file |egrep -i 'ubuntu|debian' >/dev/null 2>&1
			then
			print_delimiter
				echo -e "'portmap_rpcbind package ' check\n"	
        echo "'portmap' or 'rpcbind' check"
        dpkg -l | egrep "rpcbind|portmap" > "$tmp_file"
        [ -n "`grep portmap $tmp_file`" ] && print_ok "'portmap' installed" &&return;
        [ -n "`grep rpcbind $tmp_file`" ] && print_ok "'rpcbind' installed" &&return;
        print_fail "neither 'portmap' nor 'rpcbind' installed!!"
      fi
}

#-------------------special for linux os:suse-------------------
#for Linux os 'sles', two things special:
#1. ".site/.local" in "/etc/hosts" file has been removed. 
#2. 127.0.0.2  <hostname>.<domain> <hostname>" has been commented or removed

special_sles(){

	if ls /etc/ |grep -i suse-release >/dev/null 2>&1
	then
	print_delimiter
	echo -e "'hostname suffix ' check\n"		
		echo "special check for sles"
		if [ -n "`grep ^\s*\.site/\.local /etc/hosts`" ]; then
		 print_fail "'.site/.local' not removed from /etc/hosts!"
		else 
		 print_ok "'.site/.local' check ('.site/.local' should be removed)"
		fi
		if [ -n "`grep ^\s*127\.0\.0\.2 /etc/hosts`" ]; then 
			 print_fail "'127.0.0.2' not removed or commented from /etc/hosts!"
		else
			 print_ok "'127.0.0.2' check ('127.0.0.2' should be removed)"
		fi
	fi
}

#-----------------special for solaris---------------------
#This file(resolv.conf) should be created manually

resolv_conf_check(){
print_delimiter
echo -e "'resolv.conf file' check\n"
	if test -e /etc/resolv.conf; then
		print_ok "'/etc/resolv.conf' exist!"
	else
		print_fail "'/etc/resolv.conf' not exist!"
	fi
}

adminInstallFile_check(){
print_delimiter
echo -e "'install command' check\n"
        if test -e /var/sadm/install/admin/install; then
                print_ok "'/var/sadm/install/admin/install' exist!"
        else
                print_fail "'/var/sadm/install/admin/install' not exist!"
        fi
}


#-------------------special for hpux----------------------
#'pwgrd' should install, and check its status by cmd 'pwgr_stat'

pwgrd_check(){
print_delimiter
echo -e "'pwgrd service' check\n"

        if [ `which pwgr_stat` &>/dev/null ]; then
                echo -e "\c"
        else
                print_fail "'pwgrd' not installed"
                return
        fi

        #{
         #       echo q
        #}|pwgr_stat > "$tmp_file"

         #if [ -n "`grep Daemon.*Status.*=.*Up $tmp_file`" ];then
          #      print_ok "'pwgrd' installed and Daemon staus is UP"
         #else
          #      print_warning "'pwgrd' installed and Daemon staus is not UP"
         #fi
         if ps -ef |grep -v grep |grep pwgrd >/dev/null 2>&1
         then
         	print_ok "'pwgrd' installed and Daemon staus is UP"
         else
         	print_warning "'pwgrd' installed and Daemon staus is not UP"
         fi
}

#------------------cimserver check:------------------------
#cimserver should not be started when reboot

cimserver_check(){
        if [ -z "$(cat /etc/rc.log|grep -i 'cimserver.*started' )" ]; then
                print_ok "'cimserver' config check" 
                return;
        elif [ -z "$(ps -ef |grep ".*/opt/.*/cimserver$")" ];then

		print_delimiter
                echo "'cimserver' damemon not running(expected),"
		print_warning " but it starts during reboot (unexpected)"
		print_delimiter
		elif [ -z "$(cat /etc/rc.log|grep -i 'cimserverd.*started' )" ]; then
                print_ok "'cimserver' config check" 
                return;
        elif [ -z "$(ps -ef |grep ".*/opt/.*/cimserverd$")" ];then

		print_delimiter
                echo "'cimserver' damemon not running(expected),"
		print_warning " but it starts during reboot (unexpected)"
		print_delimiter
        else
                print_fail "'cimserver' check (not set 'cimesrver=0' in relative config )" 

        fi

}

#----------------------netcd check-------------------------
#This only exist on aix 6.1 and version above

netcd_check(){
print_delimiter
echo -e "'netcd service' check\n"  
	        if [ -e /usr/sbin/netcd ]; then 
			echo -e "\c"
		else 
			print_fail "netcd' not install!"
                	return
		fi              
      if  ps -ef |grep -v grep |grep netcd >/dev/null 2>&1
      then
             print_ok "'netcd' installed and daemon start already"
      else
             print_warning "'netcd' installed but daemon not start"
      fi
}

#----------------------mail service check-------------------------
sendmail_check(){
print_delimiter
echo -e "'sendmail service' check\n"
		if ps -ef |grep -v grep |grep sendmail >/dev/null 2>&1
	 	then 
	 		print_fail "'sendmail service' check(not disabled)"
		else
	 		print_ok "'sendmail service' status check(disabled)"
	 fi
}

#----------------------control all check-------------------------
all_check_control(){
 
	        case $platform_choice in
	         a | A )
			netcd_check   	        #AIX 6.1 and above only							               
	                IP_Hosts_check a	             
#	                getent_check
			super_normal_exist
			home_dir_check
			SshdSetting_check  
	                quit=y
	                homedir=/home/
			roothomedir=/
	                ;;
	
	         h | H )
			pwgrd_check    		#hpux only
			cimserver_check		#hpux only				                
	                IP_Hosts_check h
	                nsswitch_check	              
	                getent_check
			super_normal_exist
			home_dir_check
			SshdSetting_check  
	                quit=y
	                homedir=/home/
			roothomedir=/
			;;
	         l | L ) 
		
			nscd_check		    	
			portmap_rpcbind
			special_sles            #if os is sles, do special_sles 		
			IP_Hosts_check l
			nsswitch_check 	
			getent_check
			super_normal_exist
			home_dir_check
			SshdSetting_check  
		       	quit=y
		       	homedir=/home/
			roothomedir=/root
			;;
	          s | S )
			sendmail_check 	#differ in 7,8,9,10,11			
	                nscd_check	               	               
			adminInstallFile_check 	#solaris only
	                resolv_conf_check      	#solaris only              
	                IP_Hosts_check s	                
	                nsswitch_check	             
	                getent_check 
			super_normal_exist
			home_dir_check s
			SshdSetting_check  
	                quit=y
	                homedir=/export/home/
			roothomedir=/
			;;
		m | M )             
	                quit=y
	                homedir=/Users/
			roothomedir=/var/root
			;;
	          q | Q ) 
			quit=y
	          	exit 0
	          ;;
	              * ) echo -e "\n\033[0;33m Sorry, choice not recognized. Input Again Please! \033[0m\n"
			  ;;
	        esac

	    

#The same check for each platform
if [ $quit == "y" ]; then
alock_check
checkcorefiles	
check_log    
space_check
wesoft_dir_mode	 
ftp_check
id_check
telnet_sudo_check
if [[ $ssh_login_flag == 0 ]]; then
 	echo -e "\n\033[0;33m Since telnet check fail or users or user homedir does not exist, pls also check ssh manually! \033[0m\n"
else	
 			ssh_check		
fi 
rsh_rlogin_check
fi
}

#------------print usage-----------------
print_usage(){

echo
echo "The usage for script is as below. note: when you do not define -p option, it will verify machine using interactive way"
echo 
echo "-p | --platform platform   The name of platform is in: aix,linux,hp,solaris,mac"
echo "-h | --help                Print the usage "
echo
echo "eg: ./machine_verification -p aix"
echo
exit
}

#------------platform check -----------------

platform_check(){

	case $1 in
	aix ) platform_choice="a"
	;;
	solaris ) platform_choice="s"
	;;
#	mac) platform_choice="m"
#	;;
	linux ) platform_choice="l"
	;;
	hp ) platform_choice="h"
	;;
	mac ) platform_choice="m"
	;;
	* ) print_usage
	;;
	esac
}

#------------Here comes the main function-----------------
main(){
  
  if [[ $1 != "" ]]
  then
		case $1 in
		-p | --platform ) shift; platform=$1; platform_check $platform
		;;
		-h | --help )   print_usage
		;;
		* ) print_usage
		;;
		esac	

		 all_check_control 

  else
		touch $tmp_file
		chmod 777 $tmp_file		
	        clear
	        logo
	        quit=n
	       while [ "$quit" != "y" ]
				do
	        platform_menu_choice	  
	        all_check_control     
				done  				  
	fi 	
 	
}

ssh_login_flag=1
main $1 $2
echo -e "\033[32m Finished!\033[0m"

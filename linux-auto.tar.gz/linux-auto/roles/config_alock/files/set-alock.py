#!/usr/bin/python
import pexpect,sys
#ver = pexpect.run("ssh root@"+sys.argv[1] +" \"awk -F \( '{ print $1 }' /etc/redhat-release | sed 's/^ //g;s/ $//g'\"")
#get Linux distribution version from ansible_lsb
ver = sys.argv[2]
nPos = ver.find('(')
str =''
if nPos ==-1:
    str =ver
elif nPos >=0:
    str = ver[0:nPos]
hname = pexpect.run("ssh root@"+sys.argv[1]+ " hostname")
child = pexpect.spawn("ssh root@" + sys.argv[1]+" /usr/bin/alock --config")
child.logfile = sys.stdout
index = child.expect(['location:',pexpect.EOF,pexpect.TIMEOUT])
if index == 0:
    child.sendline('4')
    child.expect('system purpose:')
    child.sendline('3')
    child.expect('Select lock mode:')
    child.sendline('1')
    child.expect('Default value: Linux')
    child.sendline(str)
    child.expect('Default value:')
    child.sendline(hname)
    child.sendline('\r\n')
else:
    pass

#!/usr/bin/python
import pexpect,sys
child = pexpect.spawn('ssh-copy-id -i /root/.ssh/id_rsa.pub ' + sys.argv[1])
child.logfile = sys.stdout
index = child.expect(['assword:',pexpect.EOF,pexpect.TIMEOUT])
if index == 0:
    child.sendline('password')
    child.expect("#")
    child.sendline("exit")
else:
    pass

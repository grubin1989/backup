#!/usr/bin/python
import pexpect,sys
child = pexpect.spawn("ssh root@" + sys.argv[1]+" /tmp/vm/vmware-tools-distrib/vmware-install.pl")
child.logfile = sys.stdout
index = child.expect(['installation of VMware tools?',pexpect.EOF,pexpect.TIMEOUT])
if index == 0:
    child.sendline('\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r')
    # child.expect('/usr/bin')
    # child.sendline('')
    # child.expect('Select lock mode:')
    # child.sendline('1')
    # child.expect('Default value:')
    # child.sendline(ver)
    # child.expect('ENTER accepts')
    # child.sendline(hname)
    child.sendline('\r')
else:
    pass

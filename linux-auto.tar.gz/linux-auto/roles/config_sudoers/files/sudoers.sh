#!/bin/sh
re=$(sed -n '/super/p' /etc/sudoers);
if [ -z "$re" ] ; then
  echo "super ALL=(ALL)  NOPASSWD: ALL" >> /etc/sudoers
fi

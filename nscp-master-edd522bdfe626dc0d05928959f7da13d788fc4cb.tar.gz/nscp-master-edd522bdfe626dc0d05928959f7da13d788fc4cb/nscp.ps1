#˵����
#0.��Զ���Թ���Ա������ִ��:Set-ExecutionPolicy Unrestricted
#1.��Զ��powershell������en-winrm.ps1
#2.�ڱ���powershell�����д˽ű�.


#Predefine necessary information
$Username = "administrator"
$Password = 'password'
$ComputerName = "10.200.1.108"
#$ComputerName = "10.100.6.68","10.200.3.115"; #��������: ȥ��#�ţ����������ʽ����IP��ַ�����ˡ�



    #Create credential object
    $SecurePassWord = ConvertTo-SecureString -AsPlainText $Password -Force
    $Cred = New-Object -TypeName "System.Management.Automation.PSCredential" -ArgumentList $Username, $SecurePassWord
	#��װ�ű�
    $inScript = {
    $nscpversion = "nscp-0.5.0.62-Win32";
    $sharedata = "\\10.100.3.9\WinUpdateLog\wesoft\zohar\" + $nscpversion;
    Copy-Item -Path $sharedata -Destination C:\ -Recurse -Force -ErrorAction SilentlyContinue;
    cd C:\\$nscpversion;
    ./nscp.exe service --install;
    ./nscp.exe service --start;
    Get-Service | findstr "NSCP"
    }
	#ж�ؽű�
    $unScript = {
    $nscpversion = "nscp-0.5.0.62-Win32";
    if (Test-Path C:\\$nscpversion)
    {
        cd C:\\$nscpversion;
        Start-Process ./nscp.exe -ArgumentList service,--stop -Wait;
        Start-Process ./nscp.exe -ArgumentList service,--uninstall -Wait;
        cd c:\ ;
        Remove-Item C:\\$nscpversion -Force -Recurse -ErrorAction SilentlyContinue; 
        }
    }


foreach($a in $ComputerName)
{
    Set-Item wsman:\localhost\Client\TrustedHosts -value $a -Force 
    echo $a
    #Create session object with this
    $Session = New-PSSession -ComputerName $a -credential $Cred
    #ж����ǰ�汾��nscp
    #Invoke-Command
    $Job = Invoke-Command -Session $Session -Scriptblock $unScript

    #��װ���ڵİ汾
    $Job = Invoke-Command -Session $Session -Scriptblock $inScript
    echo $Job

    #Close Session
    Remove-PSSession -Session $Session
}

使用说明:   
    两端都必须以管理员身份运行。   
   1.在远端主机的powershell中执行:en-winrm.ps1   
   2.在本地powershell执行nscp.ps1脚本,执行前请做相应的修改。
﻿#说明:
#0.在远端以管理员的身份执行:Set-ExecutionPolicy Unrestricted
#1.关闭远端计算机的防火强
#2.在远端计算机上必须先在powershell里执行此脚本
netsh firewall set opmode disable;
winrm quickconfig -quiet --force;
Enable-PSRemoting -force;
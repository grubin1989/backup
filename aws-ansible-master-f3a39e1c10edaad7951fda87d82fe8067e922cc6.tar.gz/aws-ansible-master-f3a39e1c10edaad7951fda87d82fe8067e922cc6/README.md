AWS Ansible版本。
